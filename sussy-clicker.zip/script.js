suscount = 0

function addSus()
{
  suscount += 1;
  document.getElementById("suscount").innerHTML = suscount;
}

